// src/components/AccountOverview.js

import React from 'react';

const AccountOverview = () => {
  return (
    <div>
      <h2>Account Overview</h2>
      {/* Your account information goes here */}
    </div>
  );
};

export default AccountOverview;
